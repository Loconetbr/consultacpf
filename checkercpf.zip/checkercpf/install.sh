pkg update
pkg upgrade -y
pkg install openssl -y
pkg install python -y
pip install requests
pip install pyfiglet
pip install rich